country = input("De onde você é? ")

if country == "CANADA" :
    print("Hello")
elif country == "BRAZIL" :
    print("OLÁ")
elif country == "FRANCE" :
    print("Bonjour")
