# Números inteiros: -14, -2, 0, 1, 100, 401233
# Números ponto flutuante(float): -2.5 , 0.0, 98.6, 14.0
# Texto (String): ”xxx”
# Booleanos: verdadeiro (True) ou falso (False)

xx = 1
zz = type (xx)
print ("type (xx)")
print (zz)

temp = 98.6
zz = type (temp)
print ("type (temp)")
print (zz)

zz = type(1)
print ("type (1)")
print (zz)

zz = type(1.0)
print ("type(1.0)")
print (zz)
