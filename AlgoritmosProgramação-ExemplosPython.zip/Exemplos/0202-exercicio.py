# Exercícios:
# Reescreva as instruções abaixo com o mínimo de parênteses possível, mas sem alterar o resultado:
# A) 6*(3+2)
# B) 2+(6*(3+2))
# C) 2+(3*6)/(2+4)
# D) 2*(8/(3+1))
# E) 3+(16-2)/(2*(9-2))
# F) ((-12)*(-4))+(3*(-4))
# G)(6*(3*3)+6)-10

# Expressões numéricas:
# Operador | Operação
#   	   |
# 	    +  | Adição
# 	    -  | Subtração
# 	    *  | Multiplicação
# 	    /  | Divisão
# 	    // | Divisão Inteira
# 	    ** | Potência
#    	%  | Resto

print ("A) 6*(3+2)")
x = 6*(3+2)
print(x)

print ("B) 2+(6*(3+2))")
x = 2+(6*(3+2))
print(x)

print ("C) 2+(3*6)/(2+4)")
x = 2+(3*6)/(2+4)
print(x)

print ("D) 2*(8/(3+1))")
x = 2*(8/(3+1))
print(x)

print ("E) 3+(16-2)/(2*(9-2))")
x = 3+(16-2)/(2*(9-2))
print(x)

print ("F) ((-12)*(-4))+(3*(-4))")
x = ((-12)*(-4))+(3*(-4))
print(x)

print ("G) (6*(3*3)+6)-10")
x = (6*(3*3)+6)-10
print(x)
