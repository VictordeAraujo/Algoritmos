# Podemos usar "\n" para forçar uma nova linha
# Podemos usar várias instruções de impressão;
print('Hickory Dickory Dock!\nThe mouse ran up the clock')
