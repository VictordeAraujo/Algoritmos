# Exercícios:
# 1) Mostrar na tela o produto entre 28 e 43;
# 2) Mostrar na tela o resto da divisão entre 30 e 4;
# 3) Mostrar na tela a divisão inteira entre 3 e 2;

# Expressões numéricas:
# Operador | Operação
#   	   |
# 	    +  | Adição
# 	    -  | Subtração
# 	    *  | Multiplicação
# 	    /  | Divisão
# 	    // | Divisão Inteira
# 	    ** | Potência
#    	%  | Resto

print ('1 - Mostrar na tela o produto entre 28 e 43: ')
print 28 * 43

print ('2 - Mostrar na tela o resto da divisão entre 30 e 4: ')
print 30 % 4

print ('3 - Mostrar na tela a divisão inteira entre 3 e 2: ')
print 3 // 2
