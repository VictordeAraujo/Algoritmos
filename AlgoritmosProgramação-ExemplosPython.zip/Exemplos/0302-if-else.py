# O que acontece se digitarmos “SIM”
resposta = input("Gostaria de adicionar outro produto ")
if resposta == "sim" :
    print("produto adicionado")
