# Exercicíos:
# 1) Faça um programa que encontra o maior de 3 valores;
# 2) Altere o programa anterior para que ele encontre o menor de 4 valores;
# 3) Faça um programa que leia 3 valores float (n1,n2 e n3) e um valor inteiro (opcao). Se opção for:
#  1: escreve os valores em ordem crescente;
#  2: escreve os valores em ordem decrescente;
#  3: escreve o maior dentre os demais;
#   Prever situações de erro;

print("Faça um programa que encontra o maior de 3 valores")
a = int(input("Informe A: "))
b = int(input("Informe B: "))
c = int(input("Informe C: "))
if (a>b) and (a>c) :
    print ("O maior dos valores é A")
if (b>a) and (b>c) :
    print ("O maior dos valores é B")
if (c>a) and (c>b) :
    print ("O maior dos valores é C")

print ("Altere o programa anterior para que ele encontre o menor de 4 valores")

a = int(input("Informe A: "))
b = int(input("Informe B: "))
c = int(input("Informe C: "))
d = int(input("Informe D: "))
if (a>b) and (a>c) and (a>d):
    print ("O maior dos valores é A")
if (b>a) and (b>c) and (b>d):
    print ("O maior dos valores é B")
if (c>a) and (c>b) and (c>d):
    print ("O maior dos valores é C")
if (d>a) and (d>b) and (d>c):
    print ("O maior dos valores é D")

print ("Faça um programa que leia 3 valores float (n1,n2 e n3) e um valor inteiro (opcao)")
n1 = float(input("Informe n1: "))
n2 = float(input("Informe n2: "))
n3 = float(input("Informe n3: "))
opcao = int(input("""Informe a opção:
1 - valores em ordem crescente
2 - valores em ordem decrescente
3 - maior dentre os demais
"""))

if opcao == 1 :
    if (n1 < n2) and (n2 < n3) :
        print("A ordem crescente: ", n1, n2, n3)
    if (n1 < n3) and (n3 < n2) :
        print("A ordem crescente: ", n1, n3, n2)
    if (n2 < n1) and (n1 < n3) :
        print("A ordem crescente: ", n2, n1, n3)
    if (n2 < n3) and (n3 < n1) :
        print("A ordem crescente: ", n2, n3, n1)
    if (n3 < n1) and (n1 < n2):
        print("A ordem crescente: ", n3, n1, n2)
    else : # n3 < n2 and n2 < n1
        print("A ordem crescente: ", n3, n2, n1)

if opcao == 2 :
    if(n3 > n2):
        temp = n3
        n3 = n2
        b = temp

    if(n2 > n1):
        temp = n2
        n2 = n1
        n1 = temp

    if(n3 > n2):
        temp = n3
        n3 = n2
        n2 = temp
    print("A ordem decrescente: ",a," ",b," ",c)

if opcao == 3 :
    if (n1>n2) and (n1>n3):
        print ("O maior dos valores é N1")
    if (n2>n1) and (n2>n3):
        print ("O maior dos valores é N2")
    if (n3>n1) and (n3>n2):
        print ("O maior dos valores é N3")
