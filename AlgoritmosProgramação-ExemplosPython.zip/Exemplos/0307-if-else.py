# Variáveis bool
# Armazenam somente True ou False
deposito = input("Quanto quer sacar? ")
if float(deposito) > 100 :
#Set the boolean variable freeToaster to True
    semTaxa=True
#SE a variavel SemTaxa é True o saque é liberado
if semTaxa :
    print("Saque liberado")
else:
    print("Será cobrado uma taxa de 50% do valor")
