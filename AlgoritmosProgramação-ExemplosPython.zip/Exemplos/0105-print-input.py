# E se eu quiser que meu texto apareça em várias linhas?
# Podemos usar várias instruções de impressão;
print('Hickory Dickory Dock!')
print('The mouse ran up the clock')
