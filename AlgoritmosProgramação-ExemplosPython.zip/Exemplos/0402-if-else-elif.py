country = input("Where are you from? " )

if country == "CANADA" :
    print("Hello")
elif country == "GERMANY" :
    print("Guten Tag")
elif country == "FRANCE" :
    print("Bonjour")
else :
    print("Aloha/Ciao")
