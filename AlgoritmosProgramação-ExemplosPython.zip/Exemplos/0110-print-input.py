# Como podemos pedir informações ao usuário?

name = input("What is your name? ")

# A função de entrada permite que especifiquemos uma mensagem para exibir e retornar o valor digitado pelo usuário;
# Usamos uma variável para lembrar o valor inserido pelo usuário;
# Chamamos nossa variável de "nome", mas você pode chamar isso de qualquer coisa, desde que o nome da variável não contenha espaços;
