#Condição IF com números
deposito = input("Digite o valor a ser depositado")
if deposito > 100 :
    print("Você ganha um sorvete")
    print("Tenha um bom dia")
# Funciona?
