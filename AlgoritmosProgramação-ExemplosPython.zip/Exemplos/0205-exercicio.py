# Exercícios:
# Lê dois números e mostre os seguintes resultados, exatamente nesse formato:
#  Dividendo:               Divisor:                 Quociente:              Resto:
#
# Leia o numerador e o denominador de uma fração e transforme-o em um número decimal;

print ("Lê dois números e mostre os seguintes resultados, exatamente nesse formato:")
a = float(input("Informe o primeiro número: "))
b = float(input("Informe o segundo número: "))
print("Dividendo: %.2f " % a + "Divisor: %.2f " % b + "Quociente: %.2f " % float(a/b) + "Resto: %.2f " % float(a%b))

print ("Leia o numerador e o denominador de uma fração e transforme-o em um número decimal")
a = int(input("Informe o primeiro número: "))
b = int(input("Informe o segundo número: "))
print ("Primeiro número: %.2f" % float(a))
print ("Segundo número: %.2f" % float(b))
