# Agora podemos criar um programa de contador de histórias!
animal = input("What is your favorite animal? " )
building = input("Name a famous building: ")
color = input("What is your favorite color? ")
print("Hickory Dickory Dock!")
print("The "+color+" "+animal+" ran up the "+building)
