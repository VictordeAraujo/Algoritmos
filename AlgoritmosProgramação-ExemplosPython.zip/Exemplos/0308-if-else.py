# Encontre os erros
deposit = input("How much would you like to deposit? ")
if float(deposit) > 100
    print("You get a free toaster!")
freeToaster = true
else :
    print("Enjoy your mug!")
    print("Have a nice day")
