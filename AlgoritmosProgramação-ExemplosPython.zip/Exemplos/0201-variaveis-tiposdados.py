# Expressões numéricas:
# Operador | Operação
#   	   |
# 	    +  | Adição
# 	    -  | Subtração
# 	    *  | Multiplicação
# 	    /  | Divisão
# 	    // | Divisão Inteira
# 	    ** | Potência
#    	%  | Resto
# Devido ao número reduzido de caracteres (no teclado), usamos algumas simplificações;
# Asterisco representa multiplicação;
# Exponenciação é representado com 2 asteriscos;
xx = 2
xx = xx + 2
# Operação de Adição
print (xx)

yy = 4 * 12
# Operação de Multiplicação
print (yy)

zz = yy / 10
# Operação de Divisão
print (zz)

jj = 23
kk = jj % 5
# Operação de Resto(Módulo)
print (kk)

# Operação de Potência
print 2 ** 3
