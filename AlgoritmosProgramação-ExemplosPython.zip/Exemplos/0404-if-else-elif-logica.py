saturday = True
sunday = False

if saturday or sunday :
    print("Você pode dormir mais")
