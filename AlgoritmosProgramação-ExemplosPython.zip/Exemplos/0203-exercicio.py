# Exercícios:
# Mostrar a média aritmética entre 3 números passados pelo usuário;
# Leia um número e mostra seu sucessor e seu antecessor na tela;
# Leia dois números e mostre a soma. Ante do resultado, deverá aparecer a mensagem:
# SOMA
# Lê um número e mostra a terça parte deste número;

print ("Mostrar a média aritmética entre 3 números passados pelo usuário")
a = int(input("Informe o primeiro número: "))
b = int(input("Informe o segundo número: "))
c = int(input("Informe o terceiro número: "))
print (int((a+b+c)/3))

print ("Leia um número e mostra seu sucessor e seu antecessor na tela")
x = int(input("Informe o um número: "))
print ("Sucessor: ",x+1)
print ("Antecessor: ",x-1)

print ("Leia dois números e mostre a soma. Ante do resultado, deverá aparecer a mensagem: SOMA = ")
a = int(input("Informe o primeiro número: "))
b = int(input("Informe o segundo número: "))
print ("SOMA = ",a+b)

print ("Lê um número e mostra a terça parte deste número")
x = int(input("Informe um número: "))
print ("Terça parte: ",x/3)
