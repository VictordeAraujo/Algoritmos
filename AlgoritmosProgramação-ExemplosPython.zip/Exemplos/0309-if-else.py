#Encontre os erros - Correto!
deposit = input("How much would you like to deposit? ")

if float(deposit) > 100 :
    print("You get a free toaster!")
    freeToaster = True
else :
    print("Enjoy your mug!")

print("Have a nice day!")
