# Você pode acessar o valor que você armazenou mais tarde em seu código
name = input("What is your name? ")
print(name)
