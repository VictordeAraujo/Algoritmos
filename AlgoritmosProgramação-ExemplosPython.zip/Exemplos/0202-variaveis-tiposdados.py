# Regras de precedência:
#
# Parênteses                |
# Potência                  |
# Multiplicação/Divisão     |
# Adição/Subtração          |
# Esquerda para direita     v
#
# Parênteses são sempre respeitados
x = 2 *(2 - 5)
# Exponenciação
x = 2 * 2 ** 5
# Multiplicação, divisão,
x = 2 * 2 / 2 + 1
# Adição e subtração
# Esquerda para direita
