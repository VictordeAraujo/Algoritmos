# Condição IF com números
deposito = 150
if deposito > 100 :
    print("Você ganha um sorvete")
    print("Tenha um bom dia")

# deposito == 150, o que acontece?
# deposito == 50, o que acontece?
# deposito == 100, o que acontece?
