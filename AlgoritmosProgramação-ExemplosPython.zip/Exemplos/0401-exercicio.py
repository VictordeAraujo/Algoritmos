# Exercícios:
# 1) Faça um programa em Python para verifcar se um caracter é vogal ou consoante.
#  (tratar maiuscula e minuscula)
# 2) Escreva um programa que simule um caixa eletrônico. O programa recebe um valor
# do usuário e deve disponibilizar as notas de maior para menor valor. Ou seja, o
# programa deve disponibilizar o mínimo de notas para o usuário. Notas válidas:
# 1 ,50,20,10,5,1
#  Entrada: 250
#  Saída: 5 notas de 50
#  Entrada: 223
#  Saída: 4 notas de 50
#  1 nota de 20
#  3 notas de 1
print("1) Faça um programa em Python para verifcar se um caracter é vogal ou consoante.")
letra = input("Informe uma letra: ")
# letra.upper()
if letra == 'A' or letra == 'E' or letra == 'I' or letra == 'O' or letra == 'U':
    print ("Vogal")
else :
    print ("Consoante")

print ("2) Escreva um programa que simule um caixa eletrônico.")
# Obtem do usuario a quantidade que ele deseja sacar do caixa eletronico
saque = int(input('Digite o valor do saque: '))
# Quantidade máxima de notas de 50 que podem ser sacadas do valor digitado
# (apos separacao de cedulas maiores) e o que sobra para ainda ser
# distribuido entre as outras cedulas
n50 = int(saque / 50)
resto = saque % 50
# Quantidade máxima de notas de 20 que podem ser sacadas do valor digitado
# (apos separacao de cedulas maiores) e o que sobra para ainda ser
# distribuido entre as outras cedulas
n20 = int(resto / 20)
resto = resto % 20
# Quantidade máxima de notas de 10 que podem ser sacadas do valor digitado
# (apos separacao de cedulas maiores) e o que sobra para ainda ser
# distribuido entre as outras cedulas
n10 = int(resto / 10)
resto = resto % 10
# Quantidade máxima de notas de 5 que podem ser sacadas do valor digitado
# (apos separacao de cedulas maiores) e o que sobra para ainda ser
# distribuido entre as outras cedulas
n5 = int(resto / 5)
resto = resto % 5
# Quantidade máxima de notas de 1 que podem ser sacadas do valor digitado
# (apos separacao de cedulas maiores) e o que sobra para ainda ser
# distribuido entre as outras cedulas
n1 = int(resto / 1)
resto = resto % 1

# Impressao do resultado final
print ('Ao sacar', saque, 'reais, voce receberá:')
print (n50, 'notas de 50')
print (n20, 'notas de 20')
print (n10, 'notas de 10')
print (n5, 'notas de 5')
print (n1, 'notas de 1')
