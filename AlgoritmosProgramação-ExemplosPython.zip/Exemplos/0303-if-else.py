# O que acontece se digitarmos “SIM”
resposta = input("Gostaria de adicionar outro produto ")
if resposta.lower == "sim" :
    print("produto adicionado")
# .lower-> minuscula
# .upper-> maiúscula
