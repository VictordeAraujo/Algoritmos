# Podemos combinar os comandos
month = "Sep"
favBook = "Star Wars"
favEvent = "Lord of the Rings"
favMovie = "ComicCon"

if month == "Sep" or month =="Apr" or month == "Jun" or month == "Nov" :
    print("Esses meses tem 30 dias")
if favMovie == "Star Wars" and favBook == "Lord of the Rings" and favEvent == "ComiCon" :
    print("Devemos ir no cinema")
