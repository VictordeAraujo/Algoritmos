# Aqui está um truque de Python: citações triplas!
# Quando você colocamos a string entre aspas triplas,
# ela será mostrada da maneira que você tem a string
# no editor de texto;

print("""Hickory Dickory Dock!
The mouse ran up the clock""")
print('''Hickory Dickory Dock!
The mouse ran up the clock''')
