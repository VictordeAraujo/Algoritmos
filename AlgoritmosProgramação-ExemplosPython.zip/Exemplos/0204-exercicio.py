# Exercícios:
# Escreva um programa que pergunta as horas trabalhadas e valor que que a pessoa recebe por hora.
# O programa deve calcular total que a pessoa deve receber:
#  Horas trabalhadas: 35
#  Valor da hora: 2.75
#  Pagamento: 96.25
# Escreva um programa para calcular a média de 5 notas inseridas pelo usuário;

print ("Programa que pergunta as horas trabalhadas e valor que que a pessoa recebe por hora")
horaTrabalhada = float(input("Informe as horas trabalhadas: "))
valorHora = float(input("Informe o valor recebido por hora: "))
print("Horas trabalhadas: %.2f" % horaTrabalhada)
print("Valor da hora: %.2f" % valorHora)
print("Pagamento: %.2f" % float(horaTrabalhada*valorHora))

print ("Escreva um programa para calcular a média de 5 notas inseridas pelo usuário")
a = int(input("Informe a primeira nota: "))
b = int(input("Informe a segunda nota: "))
c = int(input("Informe a terceira nota: "))
d = int(input("Informe a quarta nota: "))
e = int(input("Informe a quinta nota: "))
print (int((a+b+c+d+e)/5))
