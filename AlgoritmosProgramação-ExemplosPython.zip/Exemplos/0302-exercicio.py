# Exercicíos:
# Escreva um algoritmo para determinar se uma pessoa é maior ou menor de idade

print("Escreva um algoritmo para determinar se uma pessoa é maior ou menor de idade")
idade = int(input("Informe a idade: "))
if idade >= 18 :
    print("Maior de idade")
else :
    print("Menor de idade")
