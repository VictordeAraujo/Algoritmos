# Importa se você usa aspas simples ou duplas?

print("It's a beautiful day in the neighborhood")
# Observe o problema (erro) na linha seguinte
print('It's a beautiful day in the neighborhood')
# Somente se a string que você está exibindo contiver uma aspa simples ou dupla;
# É um bom hábito escolher um e ficar com ele o máximo possível;
