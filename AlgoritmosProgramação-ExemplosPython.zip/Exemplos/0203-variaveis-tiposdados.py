# Expressões numéricas:
# Operador | Operação
#   	   |
# 	    +  | Adição
# 	    -  | Subtração
# 	    *  | Multiplicação
# 	    /  | Divisão
# 	    // | Divisão Inteira
# 	    ** | Potência
#    	%  | Resto
#
# Representação de ordem de precedência
x = 1 + 2 ** 3 / 4 * 5
print (x)
