# Você também pode alterar o valor de uma variável mais tarde no código
name = input("What is your name? ")
print(name)
name = "Mary"
print(name)
