# Números inteiros: -14, -2, 0, 1, 100, 401233
# Números ponto flutuante(float): -2.5 , 0.0, 98.6, 14.0
# Texto (String): ”xxx”
# Booleanos: verdadeiro (True) ou falso (False)
#
# A função input(“texto”) carrega informação digitada pelo usuário;
# A função input retorna uma string;
#
# Convertendo tipos

inp = input('Digite o preço do kg da laranja? ')
usf = float(inp) * 3
print ('Valor a pagar', usf)
