'''

Escreva um programa que mostrará o seguinte poema na tela:

Era uma vez um ícone de estrela de cinema
quem preferiu dormir com a luz acesa.
Eles aprenderam como codificar
um dispositivo que certamente brilhava
e iluminou a noite usando o Python!

'''
print('''Era uma vez um ícone de estrela de cinema
quem preferiu dormir com a luz acesa.
Eles aprenderam como codificar
um dispositivo que certamente brilhava
e iluminou a noite usando o Python!''')
