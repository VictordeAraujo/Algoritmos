# Então, pode ser útil praticar a descoberta de nossos erros
# Quais são os erros do programa abaixo?
print(Hickory Dickory Dock)
print('It's a small world')
print("Hi there')
prnit("Hello World!")
