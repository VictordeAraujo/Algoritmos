# Exercicíos:
# Escrever um algoritmo para ler dois valores numéricos e apresentar a diferença do maior pelo menor;
# Dados dois números A e B, some 100 ao maior número e imprima;

print ("Escrever um algoritmo para ler dois valores numéricos e apresentar a diferença do maior pelo menor")
A = int(input("Informe A: "))
B = int(input("Informe B: "))
if A > B :
    temp = A - B
    print("A é maior: A - B = %d" % temp)
else :
    temp = B - A;
    print("B é maior: B - A = %d" % temp)

print ("Dados dois números A e B, some 100 ao maior número e imprima")
A = int(input("Informe A: "))
B = int(input("Informe B: "))
if A > B :
    A = A + 100
    print("A é maior: A + 100 = %d" % A)
else :
    B = B + 100;
    print("B é maior: B + 100 = %d" % B)
