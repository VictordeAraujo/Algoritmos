# Todos os dias tomamos dezenas de decisões

resposta = input("Deseja adicionar seguro extra ao laptop? ")
if resposta == "sim" :
    print("Custará mais 2.000 reais”)

# O que esse símbolo '==' significa?
