# O que acontece se você ganha uma caneca com valor
# acima de 100 e um sorvete com outro valor?
deposito = input("Quanto quer depositar? ")
if float(deposito) > 100 :
    print("Ganhou uma caneca!")
else:
    print("Aproveite o sorvete!")
    print("Tenha um bom dia!")
# O código do else é executado se somente a condição do if for falsa;
