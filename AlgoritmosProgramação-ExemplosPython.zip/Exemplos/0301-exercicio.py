# Operadores relacionais
#
#   ==  | igualdade         | if resposta == "sim" :
#   !=  | diferente         | if resposta != "não" :
#   <   | menor             | if total < 100 :
#   >   | maior             | if total > 100 :
#   <=  | menor ou igual    | if total <= 100 :
#   >=  | maior ou igual    | if total >= 100 :
#
# Tendo as variáveis SALARIO, IR e SALLIQ, e considerando os valores abaixo,
# informe se as expressões são verdadeiras ou falsas:
# SALLIQ = 100
# SALLIQ >= 100?        (   )
#
# SALLIQ = 190
# SALLIQ < 190.00?      (   )
#
# SALLIQ = 285.00
# IR = 15.00
# SALARIO = 300.00
# SALLIQ = SALARIO - IR (   )
#
# Sabendo que A=3, B=7 e C=4, informe se as expressões abaixo são verdadeiras ou falsas:
# a) (A+C) > B     		(	)
# b) B >= (A + 2)     	(	)
# c) C == (A-B)     	(	)
# d) (B + A) <= C     	(	)
# e) (C+A) > B     		(	)
print('''Tendo as variáveis SALARIO, IR e SALLIQ, e considerando os valores abaixo,
informe se as expressões são verdadeiras ou falsas:''')
SALLIQ = 100
print("SALLIQ >= 100? ")
print(SALLIQ>=100)

SALLIQ = 190.00
print("SALLIQ < 190.00? ")
print(SALLIQ<190.00)

SALLIQ = 285.00
IR = 15.00
SALARIO = 300.00
print("SALLIQ = SALARIO - IR? ")
print(SALLIQ = SALARIO - IR)
