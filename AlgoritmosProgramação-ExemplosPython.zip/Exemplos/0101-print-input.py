# Criando o primeiro programa
print(‘Hello World’)
