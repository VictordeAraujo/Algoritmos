# Variáveis também conteúdo da variável permitem manipular
message = 'Hello world'
print(message.lower())
print(message.upper())
print(message.swapcase())
