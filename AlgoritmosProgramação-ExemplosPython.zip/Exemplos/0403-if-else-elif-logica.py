ganharLoteria = True
principalGanhador = True

if ganharLoteria and principalGanhador:
    print("You can retired")
