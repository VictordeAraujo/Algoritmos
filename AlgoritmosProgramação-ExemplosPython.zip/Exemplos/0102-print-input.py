# Em Python usamos um '#' para indicar comentários

#Meu primeiro programa em python
#Criado por mim
#O comando print mostra uma mensagem na tela
print('Hello World')
