# Muitos programas de computador fornecem informações
# Podemos usar aspas simples ou aspas duplas;
print('Hickory Dickory Dock! The mouse ranup the clock')
print("Hickory Dickory Dock! The mouse ranup the clock")
