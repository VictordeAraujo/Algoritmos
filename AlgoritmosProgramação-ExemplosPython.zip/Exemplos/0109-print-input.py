# Então, pode ser útil praticar a descoberta de nossos erros
# E agora? Correto?
print('Hickory Dickory Dock')
print("It's a small world")
print("Hi there")
print("Hello World!")
